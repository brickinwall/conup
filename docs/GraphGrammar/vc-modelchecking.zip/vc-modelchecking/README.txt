To open the Groove tool 
run vc-modelchecking/groove-5_5_3/bin/Simulator.jar

To load the vc-grammar
File -> Load Grammar and select version-consistency-grammar/version-consistency.gps

To load the grammar including the BF and CV formalization
File -> Load Grammar and select version-consistency-grammar/vc_with_BF_and_CV_strategies.gps

To load the VCC tool
File -> Load Grammar and select version-consistency-grammar/VCC-tool.gps